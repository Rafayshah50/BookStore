﻿namespace Store.Utility
{
    public class Class1
    {

    }
}
