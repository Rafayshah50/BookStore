﻿namespace Store.DataAccess
{
    public class Class1
    {

    }
}
